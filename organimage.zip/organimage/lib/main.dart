import 'package:flutter/material.dart';
import 'package:drag_and_drop_gridview/devdrag.dart';
import 'package:flutter/rendering.dart';
import 'dart:async';
import 'package:flutter/services.dart';
import 'package:image/image.dart' as imglib;
import 'package:collection/collection.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(),
        drawer: Drawer(),
        body: SingleChildScrollView(
            child: Column(children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Expanded(
                flex: 1,
                child: Center(child: Text("organimage for hackathone")),
              )
            ],
          ),
          //  Flexible(
          //   child:

          Divider(
            color: Colors.grey.shade600,
          ),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Expanded(
                flex: 5,
                child: Container(
                  width: double.infinity,
                   height: 300,
                  decoration: BoxDecoration(
                    // color: const Color(0xff7c94b6),
                    image: const DecorationImage(
                    //  image: AssetImage('assets/crossflutter.jpg'),
                      image: AssetImage('assets/b1.gif'),
                      fit: BoxFit.fill,
                    ), //   height: 150,
                  ),
                ),
              ),
            ],
          ),
          //   ),

          Divider(
            color: Colors.grey.shade600,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Expanded(
                flex: 1,
                // child: Center(
                child: ElevatedButton(
                    child: Text("Play"),
                    onPressed: () {
                      navigateToPlayPage(context);
                    }),
              ) //)
            ],
          ),
        ]
            )
        )
    );
  }

  void navigateToPlayPage(BuildContext context) {
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => PlayPage()));
  }
}

class PlayPage extends StatefulWidget {
 const PlayPage({Key? key}) : super(key: key);

  @override
  _PlayPageState createState() => _PlayPageState();
}


class _PlayPageState extends State<PlayPage> {

  List<String> truelist = [
    'assets/row-1-column-1.png',
    'assets/row-1-column-2.png',
    'assets/row-1-column-3.png',
    'assets/row-2-column-1.png',
    'assets/row-2-column-2.png',
    'assets/row-2-column-3.png',
    'assets/row-3-column-1.png',
    'assets/row-3-column-2.png',
    'assets/row-3-column-3.png',
  ];
  List<String> falselist = [

    'assets/row-1-column-3.png',
    'assets/row-2-column-3.png',
    'assets/row-1-column-1.png',
    'assets/row-1-column-2.png',
    'assets/row-3-column-1.png',
    'assets/row-3-column-2.png',
    'assets/row-2-column-1.png',
    'assets/row-2-column-2.png',
    'assets/row-3-column-3.png',
  ];
  bool variableSet = false;
  ScrollController _scrollController= ScrollController();

  double width=50;
  double height=50;

  Function eq = const ListEquality().equals;
  bool congratulation =false;
  @override




/*

  List<Image> splitImage(List<int> input) {
    // convert image to image from image package
    imglib.Image image = imglib.decodeImage(input);

    int x = 0, y = 0;
    int width = (image.width / 3).round();
    int height = (image.height / 3).round();

    // split image to parts
    List<imglib.Image> parts = List<imglib.Image>();
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
      //  parts.add(imglib.copyCrop(image, x, y, width, height));
     //   x += width;
      }
      x = 0;
    //  y += height;
    }

    // convert image from image package to Image Widget to display
   List<Image> output = List<Image>();
    for (var img in parts) {
      output.add(Image.memory(imglib.encodeJpg(img)));
    }

    return output;
  }


*/


  List<int> pathimagtolistint(String str) {
    List<int> lst =  List<int>.empty();
    return lst;
}






  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
      body: Column(children: <Widget>[
        Flexible(
      child :
      Center(
        child: DragAndDropGridView(
        controller: _scrollController,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            childAspectRatio: 3 / 3,
          ),
          padding: EdgeInsets.all(1),
          itemBuilder: (context, index) => Card(
            elevation: 1,
            child: LayoutBuilder(builder: (context, costrains) {
              if (congratulation == true){
               return MaterialApp(
                  home: Scaffold(
                    body: Column(children: <Widget>[ AlertDialog(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(
                        Radius.circular(25),
                      ),
                    ),
                    title: Text(
                      'congratulation',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13.0),
                    ))])));
              }
              if (variableSet == false) {
                height = costrains.maxHeight;
                width = costrains.maxWidth;
                variableSet=true;
              }
              return GridTile(
                child: Image.asset(
                  falselist[index],
                  height: height,
                  width: width,
                ),
              );
            }),
          ),
          isCustomChildWhenDragging: true,
          childWhenDragging: (pos) => Image.asset(
            'assets/crossflutter.png',
            height: height,
            width: width,
          ),
          itemCount: falselist.length,
          onWillAccept: (oldIndex, newIndex) => true,
          onReorder: (oldIndex, newIndex) {
            final temp = falselist[oldIndex];
            falselist[oldIndex] = falselist[newIndex];
            falselist[newIndex] = temp;

            setState(() {
            if (eq(truelist, falselist)){
            print(eq(truelist, falselist));
           congratulation=eq(truelist, falselist);
            }
            });
          },
        ),
      ),
        ),



        Divider(
          color: Colors.grey.shade600,
        ),
        Center(
          child: ElevatedButton(
            child: Text("back To Main Page"),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),

        Divider(
          color: Colors.grey.shade600,
        ),
        Center(
          child: ElevatedButton(
            child: Text("split image to parts"),
            onPressed: () {

            List<int> lst =  pathimagtolistint( 'assets/crossflutter.png');


            /* List<Image> parts= splitImage( lst);*/
            },
          ),
        ),
      ]

    ),
    ),
    );
  }

  void backToMainPage(BuildContext context) {
    Navigator.pop(context);
  }
}








