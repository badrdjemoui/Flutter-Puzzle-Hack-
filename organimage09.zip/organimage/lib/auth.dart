import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'MyHomePage.dart';

class AuthForm extends StatefulWidget {

  @override
  _AuthFormState createState() => _AuthFormState();
}

class _AuthFormState extends State<AuthForm> {
  final _formKey = GlobalKey<FormState>();
  String _email = '', _password = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
    ),
    body:
        Form(
      key: _formKey,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        child: Column(
          children: <Widget>[
            TextFormField(
              decoration: InputDecoration(
                labelText: 'Enter your email',
                hintText: 'ex: test@gmail.com',
              ),
              onChanged: (value) {
                _email = value;
              },

            ),
            SizedBox(height: 10),
            TextFormField(
              decoration: InputDecoration(
                labelText: 'Enter your password',
              ),
              obscureText: true,
              onChanged: (value) {
                _password = value;
              },

            ),
            SizedBox(height: 20),

            SizedBox(height: 6),
             Divider(
              color: Colors.grey.shade600,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Expanded(
                  flex: 1,
                  // child: Center(
                  child: ElevatedButton(
                      child: Text("log in"),
                      onPressed: () {
                        if (_email== "b" && _password =="b"){
                          navigateToMyHomePage(context);

                        }
                        else{print("code incorrect");}
                      }),
                ) //)
              ],
            ),
            Divider(
              color: Colors.grey.shade600,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Expanded(
                  flex: 1,
                  // child: Center(
                  child: ElevatedButton(
                      child: Text("close"),
                      onPressed: () {

                        Navigator.pop(context);

                      }),
                ) //)
              ],
            ),
          ],
        ),
      ),
    ),);
  }
  void navigateToMyHomePage(BuildContext context) {
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => MyHomePage()));
  }
}
