
import 'package:flutter/material.dart';
import 'package:image/image.dart' as imglib;
import 'auth.dart';

int moves=0;
void main() {

  runApp(MyApp());

}

class MyApp extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: AuthForm(),
    );
  }
}

